package pt.isec.server.services.auth;

import pt.isec.common.dto.auth.*;
import pt.isec.common.model.user.Student;
import pt.isec.common.model.user.Teacher;
import pt.isec.server.repositories.StudentDAO;
import pt.isec.server.repositories.TeacherDAO;
import pt.isec.server.repositories.entity.SessionServices;
import pt.isec.server.services.config.ConfigServices;

public class AuthService implements IAuthService {
    private final TeacherDAO teacherDAO;
    private final StudentDAO studentDAO;
    private final ConfigServices configServices = new ConfigServices();

    public AuthService(TeacherDAO teacherDAO, StudentDAO studentDAO) {
        this.teacherDAO = teacherDAO;
        this.studentDAO = studentDAO;
    }

    // Construtor auxiliar (para usar sem injeção)
    public AuthService() {
        this.teacherDAO = new TeacherDAO();
        this.studentDAO = new StudentDAO();
    }

    @Override
    public LoginResponseDTO registerTeacher(RegisterTeacherDTO dto) throws Exception {
        if (dto == null) throw new IllegalArgumentException("Dados em falta");

        String name  = dto.name();
        String email = dto.email();
        String pw    = dto.password();
        String code  = dto.teacherRegisterCode();

        // validações básicas
        if (!Validators.isValidName(name))
            throw new IllegalArgumentException("Nome inválido");
        if (!Validators.isValidEmail(email))
            throw new IllegalArgumentException("Email inválido");
        if (!Validators.isValidPassword(pw))
            throw new IllegalArgumentException("Password fraca");
        if (code == null || code.isBlank())
            throw new IllegalArgumentException("Código de registo obrigatório");

        // email único
        if (teacherDAO.existsByEmail(email) || studentDAO.existsByEmail(email))
            throw new IllegalArgumentException("Email já existe");

        // verificar código de registo do docente
        String storedHash = configServices.getTeachersRegisterHash();
        if (storedHash == null || storedHash.isBlank()
                || !PasswordHasher.verifyPassword(code, storedHash))
            throw new IllegalArgumentException("Código de registo inválido");

        // hash da password
        String passwordHash = PasswordHasher.hashPassword(pw);

        // criar e guardar docente
        Teacher teacher = new Teacher();
        teacher.setName(name);
        teacher.setEmail(email);
        teacher.setPasswordHash(passwordHash);

        long id = teacherDAO.add(teacher); // TODO implementar persistência
        teacher.setId((int) id);

        // criar sessão
        SessionServices<Teacher> sessions = new SessionServices<>();
        var session = sessions.create(teacher);

        // resposta
        return new LoginResponseDTO(
                session.getId(),
                String.valueOf(teacher.getId()),
                "TEACHER",
                teacher.getName(),
                teacher.getEmail()
        );
    }

    @Override
    public LoginResponseDTO registerStudent(RegisterStudentDTO dto) throws Exception {
        if (dto == null) throw new IllegalArgumentException("Dados em falta");

        String name   = dto.name();
        String email  = dto.email();
        String pw     = dto.password();

        Integer number;
        try {
            number = Integer.valueOf(dto.studentNumber());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Número de estudante inválido");
        }

        // validações básicas
        if (!Validators.isValidName(name))
            throw new IllegalArgumentException("Nome inválido");
        if (!Validators.isValidEmail(email))
            throw new IllegalArgumentException("Email inválido");
        if (!Validators.isValidPassword(pw))
            throw new IllegalArgumentException("Password fraca");

        // email único
        if (teacherDAO.existsByEmail(email) || studentDAO.existsByEmail(email))
            throw new IllegalArgumentException("Email já existe");

        // hash da password
        String passwordHash = PasswordHasher.hashPassword(pw);

        // criar e guardar estudante
        Student student = new Student();
        student.setName(name);
        student.setEmail(email);
        student.setPasswordHash(passwordHash);
        student.setStudentNumber(number);

        long id = studentDAO.add(student); // TODO implementar persistência
        student.setId(id);

        // criar sessão
        SessionServices<Student> sessions = new SessionServices<>();
        var session = sessions.create(student);

        // resposta
        return new LoginResponseDTO(
                session.getId(),
                number,
                "STUDENT",
                student.getName(),
                student.getEmail()
        );
    }

    @Override
    public LoginResponseDTO login(LoginRequestDTO loginRequestDTO) {
        // TODO implementar login
        return null;
    }

    @Override
    public void changePassword(ChangePasswordDTO changePasswordDTO) {
        // TODO implementar troca de senha
    }
}
